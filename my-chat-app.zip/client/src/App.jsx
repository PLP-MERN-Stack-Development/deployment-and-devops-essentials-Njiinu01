import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import axios from 'axios';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';
const SOCKET = import.meta.env.VITE_SOCKET_URL || 'http://localhost:4000';

const socket = io(SOCKET);

export default function App() {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [user, setUser] = useState(localStorage.getItem('user') || '');
  const [token, setToken] = useState(localStorage.getItem('token') || '');

  useEffect(() => {
    fetchMessages();
    socket.on('newMessage', msg => {
      setMessages(prev => [msg, ...prev]);
    });
    return () => socket.off('newMessage');
  }, []);

  async function fetchMessages() {
    const res = await axios.get(API + '/api/messages');
    setMessages(res.data);
  }

  async function sendMessage(e) {
    e.preventDefault();
    const m = { user: user || 'Anonymous', text };
    // POST to server
    await axios.post(API + '/api/messages', m, { headers: { Authorization: token ? `Bearer ${token}` : '' }});
    socket.emit('sendMessage', m);
    setText('');
  }

  async function register() {
    const username = prompt('username');
    const password = prompt('password');
    await axios.post(API + '/api/auth/register', { username, password });
    alert('registered, please login');
  }

  async function login() {
    const username = prompt('username');
    const password = prompt('password');
    const res = await axios.post(API + '/api/auth/login', { username, password });
    localStorage.setItem('token', res.data.token);
    localStorage.setItem('user', username);
    setToken(res.data.token);
    setUser(username);
  }

  return (
    <div className="app">
      <header><h1>My Chat App</h1></header>
      <div className="controls">
        <button onClick={register}>Register</button>
        <button onClick={login}>Login</button>
        <button onClick={() => { localStorage.clear(); setUser(''); setToken(''); }}>Logout</button>
        <div>Current user: {user || 'none'}</div>
      </div>
      <form onSubmit={sendMessage} className="composer">
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="Type a message" required />
        <button type="submit">Send</button>
      </form>
      <main>
        {messages.map(m => (
          <div key={m._id || Math.random()} className="message">
            <b>{m.user}:</b> {m.text}
          </div>
        ))}
      </main>
    </div>
  );
}
