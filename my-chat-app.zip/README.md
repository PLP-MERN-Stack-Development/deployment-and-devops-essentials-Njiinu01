# My Chat App — Deployment-ready MERN Example

This repository is a minimal, production-ready MERN example with:
- React frontend (Vite)
- Express + Socket.io backend (with JWT auth and MongoDB/Mongoose)
- .env.example files
- GitHub Actions CI workflow (build & deploy placeholders)
- Deployment guides for Render (backend) and Vercel (frontend)

## What to do next
1. Copy `.env.example` files into `.env` in `server/` and into `client/.env` and fill values.
2. Create a MongoDB Atlas cluster and add the connection string in `server/.env`.
3. Create Vercel and Render projects, connect GitHub repo, and add environment variables.
4. Push to GitHub. Frontend should auto-deploy on Vercel (if connected), backend on Render (if connected).
5. Configure secrets in GitHub for CI/CD if you want Actions to perform deployments.

## Local run (monorepo)
- Start backend:
  ```
  cd server
  npm ci
  npm run dev
  ```
- Start frontend:
  ```
  cd client
  npm ci
  npm run dev
  ```

## Endpoints
- Auth: POST /api/auth/register, /api/auth/login
- Messages API: GET /api/messages, POST /api/messages
- Health: GET /healthz

## Notes
- This example includes basic JWT auth (no email verification).
- Socket.io is used for real-time messages.
- CI workflow includes build steps and a Vercel deploy action for the frontend.
