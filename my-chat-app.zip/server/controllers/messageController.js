const Message = require('../models/Message');

exports.getMessages = async (req, res) => {
  const msgs = await Message.find({}).sort({ createdAt: -1 }).limit(50);
  res.json(msgs);
};

exports.postMessage = async (req, res) => {
  const { user, text } = req.body;
  const m = new Message({ user, text });
  await m.save();
  res.status(201).json(m);
};
