require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const mongoose = require('mongoose');
const { Server } = require('socket.io');
const logger = require('./utils/logger');
const authRoutes = require('./routes/authRoutes');
const messageRoutes = require('./routes/messageRoutes');

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('combined'));

app.use('/api/auth', authRoutes);
app.use('/api/messages', messageRoutes);

app.get('/healthz', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
const server = http.createServer(app);

// Socket.io
const io = new Server(server, {
  cors: {
    origin: '*',
  }
});

io.on('connection', (socket) => {
  logger.info('A user connected: %s', socket.id);
  socket.on('sendMessage', (msg) => {
    // broadcast message to all clients
    io.emit('newMessage', msg);
  });
  socket.on('disconnect', () => {
    logger.info('User disconnected: %s', socket.id);
  });
});

// Connect DB and start server
async function start() {
  try {
    await mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    logger.info('Connected to MongoDB');
    server.listen(PORT, () => logger.info('Server listening on ' + PORT));
  } catch (err) {
    logger.error('Failed to start', err);
    process.exit(1);
  }
}
start();
